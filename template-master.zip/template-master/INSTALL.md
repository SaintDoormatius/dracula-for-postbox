### [X](http://link-to-x.com)

#### Install using Git

If you are a git user, you can install the theme and keep up to date by cloning the repo:

    $ git clone https://github.com/dracula/template.git

#### Install manually

Download using the [GitHub .zip download](https://github.com/dracula/template/archive/master.zip) option and unzip them.

#### Activating theme

1. Do this
2. Then that
3. Boom! It's working