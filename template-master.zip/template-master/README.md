# Dracula for [X](http://link-to-x.com)

> A dark theme for [X](http://link-to-x.com).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/x](https://draculatheme.com/x).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/dracula/template/graphs/contributors).

[![Zeno Rocha](https://github.com/zenorocha.png?size=100)](https://github.com/zenorocha) |
--- |
[Zeno Rocha](https://github.com/zenorocha) |

## License

[MIT License](./LICENSE)